#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[]) {
    printf("Hello from test-meson!\n");
    printf("Built with Meson build system.\n");
    if (argc > 1 && strcmp(argv[1], "--version") == 0) {
        printf("test-meson version 1.0\n");
    }
    return 0;
}
