#include <stdio.h>
#include <string.h>
#include <math.h>  /* Link against libm to have some shared lib */

int main(int argc, char *argv[]) {
    printf("Hello from test-gui-app!\n");
    printf("This simulates a GUI application.\n");
    printf("Math test: sqrt(16) = %.0f\n", sqrt(16.0));
    if (argc > 1 && strcmp(argv[1], "--version") == 0) {
        printf("test-gui-app version 1.0\n");
    }
    return 0;
}
