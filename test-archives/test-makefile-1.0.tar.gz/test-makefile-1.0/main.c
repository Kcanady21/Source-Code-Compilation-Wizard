#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[]) {
    printf("Hello from test-makefile!\n");
    printf("Built with plain Makefile.\n");
    if (argc > 1 && strcmp(argv[1], "--version") == 0) {
        printf("test-makefile version 1.0\n");
    }
    return 0;
}
