#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[]) {
    printf("Hello from test-autotools!\n");
    printf("This program was compiled and installed via the Source Compile Wizard.\n");
    if (argc > 1 && strcmp(argv[1], "--version") == 0) {
        printf("test-autotools version 1.0\n");
    }
    return 0;
}
