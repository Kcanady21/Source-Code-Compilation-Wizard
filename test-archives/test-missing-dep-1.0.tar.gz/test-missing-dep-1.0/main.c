#include <stdio.h>
#include <nonexistent_library.h>  /* This will fail */

int main() {
    printf("This should not compile!\n");
    return 0;
}
