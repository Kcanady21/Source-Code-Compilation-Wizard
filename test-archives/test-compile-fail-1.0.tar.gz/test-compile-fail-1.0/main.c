#include <stdio.h>

int main() {
    printf("This has a syntax error!\n")  /* Missing semicolon */
    int x = ;  /* Invalid syntax */
    return 0;
}
