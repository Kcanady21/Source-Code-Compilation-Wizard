#include <stdio.h>

int main() {
    printf("Hello! I have no build system.\n");
    printf("You'll need to force one to build me.\n");
    return 0;
}
